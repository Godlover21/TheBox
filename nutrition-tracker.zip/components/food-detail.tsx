import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Image from "next/image"

export default function FoodDetail({
  name = "Grilled Sirloin Steak Meal With Sides",
  calories = 1150,
  protein = 79,
  carbs = 70,
  fat = 70,
  healthScore = 7,
  imageUrl = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg",
}) {
  return (
    <Card className="overflow-hidden">
      <div className="relative h-48">
        <Image src={imageUrl || "/placeholder.svg"} alt={name} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-4">
          <h2 className="text-white text-xl font-bold">{name}</h2>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <div className="text-2xl font-bold">{calories} kcal</div>
          <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
            Health Score: {healthScore}/10
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Protein</span>
              <span className="text-sm font-medium">{protein}g</span>
            </div>
            <Progress value={(protein / 150) * 100} className="h-2 bg-orange-100" />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Carbs</span>
              <span className="text-sm font-medium">{carbs}g</span>
            </div>
            <Progress value={(carbs / 325) * 100} className="h-2 bg-purple-100" />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Fat</span>
              <span className="text-sm font-medium">{fat}g</span>
            </div>
            <Progress value={(fat / 80) * 100} className="h-2 bg-amber-100" />
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <h3 className="font-medium">Ingredients</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-50 p-2 rounded-md text-sm">Sirloin Steak (8oz)</div>
            <div className="bg-gray-50 p-2 rounded-md text-sm">Fried Eggs (2)</div>
            <div className="bg-gray-50 p-2 rounded-md text-sm">Roasted Potatoes</div>
            <div className="bg-gray-50 p-2 rounded-md text-sm">Mixed Greens</div>
          </div>

          <h3 className="font-medium">Nutritional Benefits</h3>
          <div className="text-sm text-gray-600">
            <p>
              High in protein which helps with muscle maintenance and satiety. Contains essential nutrients like iron,
              zinc, and B vitamins from the steak. The eggs provide additional protein and healthy fats.
            </p>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-2"
              >
                <path d="M12 20h9" />
                <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />
              </svg>
              Edit
            </Button>
            <Button className="flex-1 bg-green-600 hover:bg-green-700">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-2"
              >
                <path d="M12 5v14" />
                <path d="M5 12h14" />
              </svg>
              Add to Log
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

