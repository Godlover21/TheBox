"use client"

import { useState } from "react"
import { Progress } from "@/components/ui/progress"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { CircularProgressbar, buildStyles } from "react-circular-progressbar"
import "react-circular-progressbar/dist/styles.css"
import { format, addDays, startOfWeek } from "date-fns"

export default function HomePage({ toggleDarkMode, isDarkMode }) {
  const today = new Date()
  const [selectedDate, setSelectedDate] = useState(today)
  const startOfCurrentWeek = startOfWeek(today, { weekStartsOn: 1 }) // Start on Monday
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = addDays(startOfCurrentWeek, i)
    return {
      dayName: format(date, "EEE"),
      dayNumber: format(date, "d"),
      date: date,
      isToday: format(date, "yyyy-MM-dd") === format(today, "yyyy-MM-dd"),
    }
  })
  const [showWaterModal, setShowWaterModal] = useState(false)
  const [showWeightModal, setShowWeightModal] = useState(false)

  const caloriesConsumed = 1009
  const caloriesGoal = 2500
  const caloriesLeft = caloriesGoal - caloriesConsumed
  const caloriesPercentage = Math.round((caloriesConsumed / caloriesGoal) * 100)

  return (
    <div className="flex flex-col h-full overflow-auto pb-24 px-5 pt-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">NutriScan</h1>
          <p className="text-slate-500 dark:text-slate-400">AI-powered nutrition tracking</p>
        </div>
        <button
          onClick={toggleDarkMode}
          className="w-10 h-10 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-800"
        >
          {isDarkMode ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="4" />
              <path d="M12 2v2" />
              <path d="M12 20v2" />
              <path d="m4.93 4.93 1.41 1.41" />
              <path d="m17.66 17.66 1.41 1.41" />
              <path d="M2 12h2" />
              <path d="M20 12h2" />
              <path d="m6.34 17.66-1.41 1.41" />
              <path d="m19.07 4.93-1.41 1.41" />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
            </svg>
          )}
        </button>
      </div>

      {/* Calendar */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-sm font-medium">{format(selectedDate, "MMMM yyyy")}</h2>
          <div className="flex items-center gap-1">
            <button className="w-6 h-6 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-800">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6" />
              </svg>
            </button>
            <button className="w-6 h-6 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-800">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m9 18 6-6-6-6" />
              </svg>
            </button>
          </div>
        </div>

        <div className="flex justify-between">
          {weekDays.map((day, index) => (
            <div key={day.dayName} className="flex flex-col items-center" onClick={() => setSelectedDate(day.date)}>
              <span className="text-xs text-slate-500 dark:text-slate-400 mb-1">{day.dayName}</span>
              <div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all",
                  format(selectedDate, "yyyy-MM-dd") === format(day.date, "yyyy-MM-dd")
                    ? "bg-gradient-to-br from-violet-600 to-indigo-600 text-white"
                    : day.isToday
                      ? "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300",
                )}
                className="active:scale-95 transition-transform"
              >
                {day.dayNumber}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Calories Circle */}
      <div className="mb-6">
        <Card className="p-4 bg-gradient-to-br from-slate-900/5 to-slate-900/10 dark:from-white/5 dark:to-white/10 backdrop-blur-lg border-0 shadow-lg">
          <div className="flex items-center gap-4">
            <div className="w-24 h-24 relative">
              <CircularProgressbar
                value={caloriesPercentage}
                strokeWidth={10}
                styles={buildStyles({
                  pathColor: "#8b5cf6",
                  trailColor: isDarkMode ? "#334155" : "#e2e8f0",
                })}
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-lg font-bold">{caloriesLeft}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400">kcal left</div>
              </div>
            </div>
            <div className="flex-1">
              <div className="mb-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-medium flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-violet-500"></span>
                    Protein
                  </span>
                  <span className="text-xs font-medium">95 / 120g</span>
                </div>
                <Progress value={79} className="h-1.5 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-violet-500 to-purple-500 rounded-full" />
                </Progress>
              </div>

              <div className="mb-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-medium flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    Carbs
                  </span>
                  <span className="text-xs font-medium">200 / 325g</span>
                </div>
                <Progress value={61.5} className="h-1.5 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" />
                </Progress>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-medium flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                    Fat
                  </span>
                  <span className="text-xs font-medium">100 / 111g</span>
                </div>
                <Progress value={90} className="h-1.5 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-teal-500 to-emerald-500 rounded-full" />
                </Progress>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Recently Consumed */}
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Recently Consumed</h2>
        <div className="space-y-4">
          <FoodCard
            name="Chicken Caesar Salad"
            time="12:03 AM"
            calories={700}
            protein={45}
            carbs={35}
            fat={40}
            image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg"
          />

          <FoodCard
            name="Spaghetti Bolognese"
            time="12:02 AM"
            calories={620}
            protein={25}
            carbs={75}
            fat={20}
            image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/750x750bb-ysCWUY1hbWUAIBdpWmMtfhuiwBogB9.jpeg"
          />

          <FoodCard
            name="Cheeseburger with Fries"
            time="12:01 AM"
            calories={850}
            protein={35}
            carbs={65}
            fat={45}
            image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg"
          />
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          variant="outline"
          className="h-12 bg-slate-100/50 dark:bg-slate-800/50 backdrop-blur-sm border-slate-200 dark:border-slate-700 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 text-sm"
          onClick={() => setShowWaterModal(true)}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2 text-blue-500"
          >
            <path d="M12 2v1" />
            <path d="M12 7v1" />
            <path d="M12 12v1" />
            <path d="M12 17v1" />
            <path d="M12 22v-1" />
            <path d="M17 3.34a10 10 0 0 1 0 17.32" />
            <path d="M7 3.34a10 10 0 0 0 0 17.32" />
          </svg>
          Log Water
        </Button>

        <Button
          variant="outline"
          className="h-12 bg-slate-100/50 dark:bg-slate-800/50 backdrop-blur-sm border-slate-200 dark:border-slate-700 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 text-sm"
          onClick={() => setShowWeightModal(true)}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2 text-violet-500"
          >
            <path d="M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973" />
            <path d="m9 20 3-3-3-3" />
            <path d="m6 16-3-3 3-3" />
          </svg>
          Log Weight
        </Button>
      </div>

      {showWaterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-md shadow-xl animate-in fade-in zoom-in duration-300">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Log Water Intake</h2>
              <button
                onClick={() => setShowWaterModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-700"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </button>
            </div>

            <div className="mb-6">
              <div className="flex justify-center mb-4">
                <div className="w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-blue-500"
                  >
                    <path d="M12 2v1" />
                    <path d="M12 7v1" />
                    <path d="M12 12v1" />
                    <path d="M12 17v1" />
                    <path d="M12 22v-1" />
                    <path d="M17 3.34a10 10 0 0 1 0 17.32" />
                    <path d="M7 3.34a10 10 0 0 0 0 17.32" />
                  </svg>
                </div>
              </div>

              <div className="text-center mb-6">
                <div className="text-3xl font-bold mb-1">1.8L / 2.5L</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Today's water intake</div>
              </div>

              <div className="grid grid-cols-4 gap-2 mb-4">
                {[100, 200, 300, 500].map((amount) => (
                  <button
                    key={amount}
                    className="bg-slate-100 dark:bg-slate-700 rounded-xl p-3 text-center hover:bg-blue-50 dark:hover:bg-blue-900/20"
                  >
                    <div className="font-medium">{amount}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">ml</div>
                  </button>
                ))}
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 h-12 rounded-xl border-slate-200 dark:border-slate-700"
                  onClick={() => setShowWaterModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white"
                  onClick={() => setShowWaterModal(false)}
                >
                  Add Water
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showWeightModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-md shadow-xl animate-in fade-in zoom-in duration-300">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Log Weight</h2>
              <button
                onClick={() => setShowWeightModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-700"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </button>
            </div>

            <div className="mb-6">
              <div className="flex justify-center mb-4">
                <div className="w-24 h-24 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-violet-500"
                  >
                    <path d="M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973" />
                    <path d="m9 20 3-3-3-3" />
                    <path d="m6 16-3-3 3-3" />
                  </svg>
                </div>
              </div>

              <div className="relative mb-6">
                <input
                  type="number"
                  className="w-full h-16 text-center text-3xl font-bold bg-slate-100 dark:bg-slate-700 rounded-xl border-0 focus:ring-2 focus:ring-violet-500"
                  defaultValue="178"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-lg text-slate-500 dark:text-slate-400">
                  lbs
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 h-12 rounded-xl border-slate-200 dark:border-slate-700"
                  onClick={() => setShowWeightModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 h-12 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                  onClick={() => setShowWeightModal(false)}
                >
                  Save Weight
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function FoodCard({ name, time, calories, protein, carbs, fat, image }) {
  return (
    <div
      className="bg-white dark:bg-slate-800/50 rounded-xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-700"
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <div className="flex">
        <div className="w-16 h-16 relative">
          <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
        </div>
        <div className="flex-1 p-2">
          <div className="flex justify-between">
            <h3 className="font-medium text-sm">{name}</h3>
            <span className="text-xs text-slate-500 dark:text-slate-400">{time}</span>
          </div>
          <div className="grid grid-cols-4 gap-1 mt-1">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Cal</div>
              <div className="font-medium text-xs">{calories}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Prot</div>
              <div className="font-medium text-xs">{protein}g</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Carb</div>
              <div className="font-medium text-xs">{carbs}g</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Fat</div>
              <div className="font-medium text-xs">{fat}g</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

