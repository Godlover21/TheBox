"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function DietPlanWizard() {
  const [step, setStep] = useState(0)

  const nextStep = () => {
    setStep((prev) => prev + 1)
  }

  const prevStep = () => {
    setStep((prev) => Math.max(0, prev - 1))
  }

  return (
    <div className="space-y-4">
      {step === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Create Your Diet Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 mb-6">
              Our AI will create a personalized diet plan based on your goals, preferences, and lifestyle.
            </p>
            <Button onClick={nextStep} className="w-full">
              Get Started
            </Button>
          </CardContent>
        </Card>
      ) : step === 1 ? (
        <Card>
          <CardHeader>
            <CardTitle>What's your goal?</CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup defaultValue="lose-weight" className="space-y-3">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="lose-weight" id="lose-weight" />
                <Label htmlFor="lose-weight" className="flex flex-col">
                  <span>Lose Weight</span>
                  <span className="text-sm text-gray-500">Reduce body fat while maintaining muscle</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="gain-muscle" id="gain-muscle" />
                <Label htmlFor="gain-muscle" className="flex flex-col">
                  <span>Gain Muscle</span>
                  <span className="text-sm text-gray-500">Increase muscle mass and strength</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="maintain" id="maintain" />
                <Label htmlFor="maintain" className="flex flex-col">
                  <span>Maintain Weight</span>
                  <span className="text-sm text-gray-500">Stay at your current weight but improve health</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="health" id="health" />
                <Label htmlFor="health" className="flex flex-col">
                  <span>Improve Health</span>
                  <span className="text-sm text-gray-500">Focus on overall wellness and nutrition</span>
                </Label>
              </div>
            </RadioGroup>

            <div className="flex gap-2 mt-6">
              <Button onClick={prevStep} variant="outline" className="flex-1">
                Back
              </Button>
              <Button onClick={nextStep} className="flex-1">
                Next
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : step === 2 ? (
        <Card>
          <CardHeader>
            <CardTitle>Dietary Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="diet-type">Diet Type</Label>
                <Select defaultValue="no-preference">
                  <SelectTrigger id="diet-type">
                    <SelectValue placeholder="Select diet type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no-preference">No Preference</SelectItem>
                    <SelectItem value="keto">Keto</SelectItem>
                    <SelectItem value="paleo">Paleo</SelectItem>
                    <SelectItem value="vegan">Vegan</SelectItem>
                    <SelectItem value="vegetarian">Vegetarian</SelectItem>
                    <SelectItem value="mediterranean">Mediterranean</SelectItem>
                    <SelectItem value="intermittent-fasting">Intermittent Fasting</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="allergies">Allergies or Restrictions</Label>
                <Select defaultValue="none">
                  <SelectTrigger id="allergies">
                    <SelectValue placeholder="Select allergies" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="gluten">Gluten</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="nuts">Nuts</SelectItem>
                    <SelectItem value="shellfish">Shellfish</SelectItem>
                    <SelectItem value="soy">Soy</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="cooking-time">Preferred Cooking Time</Label>
                <Select defaultValue="medium">
                  <SelectTrigger id="cooking-time">
                    <SelectValue placeholder="Select cooking time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="quick">Quick (under 15 min)</SelectItem>
                    <SelectItem value="medium">Medium (15-30 min)</SelectItem>
                    <SelectItem value="long">I enjoy cooking (30+ min)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <Button onClick={prevStep} variant="outline" className="flex-1">
                Back
              </Button>
              <Button onClick={nextStep} className="flex-1">
                Next
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Your Personalized Diet Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-medium text-green-800">Weight Loss Plan</h3>
                <p className="text-sm text-green-700 mt-1">
                  Based on your goals and preferences, we've created a personalized weight loss plan that focuses on
                  balanced nutrition while maintaining a calorie deficit.
                </p>
              </div>

              <div>
                <h3 className="font-medium mb-2">Daily Macronutrient Targets</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <div className="text-sm text-gray-500">Calories</div>
                    <div className="font-bold text-lg">1,800</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <div className="text-sm text-gray-500">Protein</div>
                    <div className="font-bold text-lg">135g</div>
                    <div className="text-xs text-gray-500">30%</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <div className="text-sm text-gray-500">Carbs</div>
                    <div className="font-bold text-lg">157g</div>
                    <div className="text-xs text-gray-500">35%</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <div className="text-sm text-gray-500">Fat</div>
                    <div className="font-bold text-lg">70g</div>
                    <div className="text-xs text-gray-500">35%</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <div className="text-sm text-gray-500">Fiber</div>
                    <div className="font-bold text-lg">25g</div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Sample Meal Plan</h3>
                <div className="space-y-2">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="font-medium">Breakfast (7:00 AM)</div>
                    <div className="text-sm text-gray-600">Greek yogurt with berries and a tablespoon of honey</div>
                    <div className="text-xs text-gray-500 mt-1">350 calories | 25g protein | 30g carbs | 12g fat</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="font-medium">Lunch (12:00 PM)</div>
                    <div className="text-sm text-gray-600">
                      Grilled chicken salad with olive oil and balsamic dressing
                    </div>
                    <div className="text-xs text-gray-500 mt-1">450 calories | 40g protein | 20g carbs | 25g fat</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="font-medium">Dinner (6:30 PM)</div>
                    <div className="text-sm text-gray-600">Baked salmon with quinoa and roasted vegetables</div>
                    <div className="text-xs text-gray-500 mt-1">550 calories | 45g protein | 40g carbs | 25g fat</div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-2">
                <Button onClick={prevStep} variant="outline" className="flex-1">
                  Back
                </Button>
                <Button className="flex-1">Save Plan</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

