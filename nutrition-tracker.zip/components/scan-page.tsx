"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { Loader2, Camera, Scan, X, Search, AlertTriangle, Check } from "lucide-react"

export default function ScanPage() {
  const [scanState, setScanState] = useState("initial") // initial, scanning, analyzing, results
  const [scanProgress, setScanProgress] = useState(0)
  const progressInterval = useRef(null)
  const [activeInputMethod, setActiveInputMethod] = useState(null)
  const [foodInput, setFoodInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [nutritionData, setNutritionData] = useState(null)
  const [error, setError] = useState("")
  const [scanFeedback, setScanFeedback] = useState("")
  const [recentSearches, setRecentSearches] = useState(["Chicken Breast", "Salmon Fillet", "Brown Rice", "Avocado"])

  // Reset scan state when component unmounts
  useEffect(() => {
    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current)
      }
    }
  }, [])

  // Function to start camera scanning
  const startScan = () => {
    setScanState("scanning")
    setScanProgress(0)
    setIsLoading(true)
    setScanFeedback("Positioning camera...")

    // Simulate scanning progress
    progressInterval.current = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval.current)
          setScanState("analyzing")
          return 0
        }
        return prev + 2
      })
    }, 50)

    // After scanning, move to analyzing
    setTimeout(() => {
      clearInterval(progressInterval.current)
      setScanState("analyzing")
      setScanProgress(0)
      setScanFeedback("Analyzing nutritional content...")

      // Start analyzing progress
      progressInterval.current = setInterval(() => {
        setScanProgress((prev) => {
          if (prev >= 100) {
            clearInterval(progressInterval.current)
            return 100
          }
          return prev + 4
        })
      }, 50)

      // Simulate AI analysis with sample data
      setTimeout(() => {
        clearInterval(progressInterval.current)

        // In a real app, this would be an actual image description from computer vision
        const imageDescription = "A plate with grilled sirloin steak, two fried eggs, and roasted potatoes with herbs"

        // Call the API to analyze the food
        analyzeFoodFromImage(imageDescription)
          .then(() => {
            setScanState("results")
            setIsLoading(false)
          })
          .catch((err) => {
            setError("Failed to analyze food. Please try again.")
            resetScan()
            setIsLoading(false)
          })
      }, 3000)
    }, 3000)
  }

  // Function to analyze food from image
  const analyzeFoodFromImage = async (imageDescription) => {
    try {
      setScanFeedback("Sending to OpenAI for analysis...")

      const response = await fetch("/api/analyze-food", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: imageDescription,
          isImage: true,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to analyze food: ${response.status}`)
      }

      const result = await response.json()

      if (!result.data) {
        throw new Error("Invalid response format from API")
      }

      setNutritionData(result.data)
      return result.data
    } catch (error) {
      console.error("Error analyzing food from image:", error)
      setError(`Failed to analyze food: ${error.message}`)
      throw error
    }
  }

  // Function to analyze food from text input
  const analyzeFoodFromText = async (inputText = null) => {
    const textToAnalyze = inputText || foodInput

    if (!textToAnalyze.trim()) {
      setError("Please enter a food description")
      return
    }

    setIsLoading(true)
    setError("")
    setScanFeedback("Analyzing your food...")

    try {
      const response = await fetch("/api/analyze-food", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: textToAnalyze,
          isImage: false,
        }),
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const result = await response.json()

      if (!result.data) {
        throw new Error("Invalid response format")
      }

      // Add to recent searches if not already there
      if (!recentSearches.includes(textToAnalyze)) {
        setRecentSearches((prev) => [textToAnalyze, ...prev.slice(0, 3)])
      }

      setNutritionData(result.data)
      setScanState("results")
      setActiveInputMethod(null)
      setIsLoading(false)
    } catch (error) {
      console.error("Error analyzing food from text:", error)
      setError(`Analysis failed: ${error.message}`)
      setIsLoading(false)
    }
  }

  // Function to analyze food from barcode
  const analyzeFoodFromBarcode = async (barcodeData) => {
    setIsLoading(true)
    setError("")
    setScanFeedback("Looking up barcode...")

    try {
      // In a real app, you would first query a barcode database
      // Then pass the product name to the OpenAI API
      const response = await fetch("/api/analyze-food", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: barcodeData,
          isImage: false,
          isBarcode: true,
        }),
      })

      if (!response.ok) {
        throw new Error(`Barcode lookup failed: ${response.status}`)
      }

      const result = await response.json()

      if (!result.data) {
        throw new Error("Invalid barcode data format")
      }

      setNutritionData(result.data)
      setScanState("results")
      setActiveInputMethod(null)
      setIsLoading(false)
    } catch (error) {
      console.error("Error analyzing barcode:", error)
      setError(`Barcode analysis failed: ${error.message}`)
      setIsLoading(false)
    }
  }

  // Function to simulate barcode scanning
  const simulateBarcodeScanning = () => {
    setIsLoading(true)
    setScanFeedback("Scanning barcode...")

    setTimeout(() => {
      setScanFeedback("Barcode detected! Looking up product...")

      setTimeout(() => {
        // Simulate barcode scan with sample data
        const barcodeData = "Protein Bar - Chocolate Peanut Butter (240 calories)"
        analyzeFoodFromBarcode(barcodeData).catch((err) => {
          setError("Failed to analyze barcode. Please try again.")
          setIsLoading(false)
        })
      }, 2000)
    }, 2000)
  }

  // Function to reset scan state
  const resetScan = () => {
    setScanState("initial")
    setScanProgress(0)
    setNutritionData(null)
    setError("")
    setScanFeedback("")
    if (progressInterval.current) {
      clearInterval(progressInterval.current)
    }
  }

  return (
    <div className="flex flex-col h-full overflow-auto pb-24 px-4 sm:px-5 pt-4 sm:pt-6">
      {/* Header */}
      <div className="mb-4 sm:mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Food Scanner</h1>
        <p className="text-slate-500 dark:text-slate-400">AI-powered nutritional analysis</p>
      </div>

      {/* Scan Area */}
      <div className="flex-1 flex flex-col">
        <div className="relative aspect-[4/5] sm:aspect-[3/4] w-full rounded-2xl sm:rounded-3xl overflow-hidden mb-4 sm:mb-6 bg-slate-200 dark:bg-slate-800">
          <div>
            {scanState === "initial" && (
              <div
                key="initial"
                className="absolute inset-0 flex flex-col items-center justify-center p-4 sm:p-6 text-center animate-in fade-in duration-300"
              >
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center mb-4 sm:mb-6">
                  <Camera size={32} className="text-violet-600 dark:text-violet-400" />
                </div>
                <h2 className="text-xl font-bold mb-2">Scan Your Food</h2>
                <p className="text-slate-500 dark:text-slate-400 mb-4 sm:mb-6 max-w-xs">
                  Point your camera at your meal to get instant nutritional information powered by AI
                </p>
                <Button
                  onClick={startScan}
                  className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white rounded-full px-6 py-5 h-auto"
                >
                  Start Scanning
                </Button>
              </div>
            )}

            {scanState === "scanning" && (
              <div key="scanning" className="absolute inset-0 animate-in fade-in duration-300">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg"
                  alt="Food being scanned"
                  fill
                  className="object-cover"
                />

                {/* Scanning overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="w-full max-w-xs px-4">
                    <div className="relative h-1 bg-white/30 rounded-full overflow-hidden mb-2">
                      <div
                        className="absolute inset-y-0 left-0 bg-white transition-all duration-300"
                        style={{ width: `${scanProgress}%` }}
                      />
                    </div>
                    <div className="text-white text-center text-sm font-medium">
                      {scanFeedback || "Scanning food..."}
                    </div>
                  </div>
                </div>

                {/* Scanning frame */}
                <div className="absolute inset-0 p-8">
                  <div className="w-full h-full border-2 border-white rounded-2xl border-dashed animate-pulse" />
                </div>
              </div>
            )}

            {scanState === "analyzing" && (
              <div key="analyzing" className="absolute inset-0 animate-in fade-in duration-300">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg"
                  alt="Food being analyzed"
                  fill
                  className="object-cover opacity-50"
                />

                {/* AI analysis visualization */}
                <div className="absolute inset-0 bg-gradient-to-b from-violet-900/50 to-indigo-900/70 flex flex-col items-center justify-center p-4 sm:p-6">
                  <div className="w-full max-w-xs mb-4 sm:mb-6 px-4">
                    <div className="relative h-1 bg-white/30 rounded-full overflow-hidden mb-2">
                      <div
                        className="absolute inset-y-0 left-0 bg-white transition-all duration-300"
                        style={{ width: `${scanProgress}%` }}
                      />
                    </div>
                  </div>

                  <div className="text-white text-center mb-6 sm:mb-8">
                    <h3 className="text-xl font-bold mb-2">AI Analyzing</h3>
                    <p className="text-white/80">
                      {scanFeedback || "Identifying ingredients and calculating nutrition"}
                    </p>
                  </div>

                  {/* AI analysis visualization */}
                  <div className="w-full max-w-xs px-4">
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {[1, 2, 3, 4, 5, 6].map((item) => (
                        <div
                          key={item}
                          className={cn(
                            "h-12 sm:h-16 rounded-lg border border-white/20 flex items-center justify-center",
                            "bg-white/10 backdrop-blur-sm",
                          )}
                        >
                          <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-white/20 animate-pulse" />
                        </div>
                      ))}
                    </div>

                    <div className="space-y-2">
                      {[1, 2, 3].map((item) => (
                        <div key={item} className="h-3 sm:h-4 bg-white/20 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-white/40 animate-pulse"
                            style={{
                              width: `${Math.random() * 100}%`,
                              animationDelay: `${item * 0.2}s`,
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {scanState === "results" && nutritionData && (
              <div key="results" className="absolute inset-0 flex flex-col animate-in fade-in duration-300">
                <div className="relative flex-1">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-aZEROPyusG5KryX3HT2Ub0M7riOcTa.jpeg"
                    alt="Analyzed food"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-x-0 bottom-0 p-4 sm:p-6 bg-gradient-to-t from-black/80 to-transparent">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {nutritionData.ingredients &&
                        nutritionData.ingredients.slice(0, 3).map((ingredient, index) => (
                          <div
                            key={index}
                            className="px-2 sm:px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-white text-xs font-medium"
                          >
                            {ingredient}
                          </div>
                        ))}
                    </div>
                    <h2 className="text-xl sm:text-2xl font-bold text-white mb-1">{nutritionData.name}</h2>
                    <p className="text-white/80 text-xs sm:text-sm">
                      {nutritionData.ingredients && nutritionData.ingredients.length > 3
                        ? `With ${nutritionData.ingredients.slice(3).join(", ")}`
                        : ""}
                    </p>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-t-2xl sm:rounded-t-3xl -mt-6 relative z-10 shadow-lg">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-xl sm:text-2xl font-bold">{nutritionData.calories} kcal</div>
                    <div className="px-2 sm:px-3 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-full text-xs sm:text-sm font-medium flex items-center gap-1">
                      <Check size={16} />
                      Health Score: {nutritionData.healthScore}/10
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 sm:gap-4 mb-4 sm:mb-6">
                    <NutrientCard
                      label="Protein"
                      value={`${nutritionData.protein}g`}
                      percentage={(nutritionData.protein * 100) / 120}
                      color="from-violet-500 to-purple-500"
                    />
                    <NutrientCard
                      label="Carbs"
                      value={`${nutritionData.carbs}g`}
                      percentage={(nutritionData.carbs * 100) / 325}
                      color="from-blue-500 to-indigo-500"
                    />
                    <NutrientCard
                      label="Fat"
                      value={`${nutritionData.fat}g`}
                      percentage={(nutritionData.fat * 100) / 80}
                      color="from-teal-500 to-emerald-500"
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 h-12 sm:h-14 rounded-xl border-slate-200 dark:border-slate-700"
                      onClick={resetScan}
                    >
                      Scan Again
                    </Button>
                    <Button className="flex-1 h-12 sm:h-14 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white">
                      Add to Log
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Alternative Methods */}
        <div className="space-y-4">
          <h2 className="text-lg sm:text-xl font-bold">Other Input Methods</h2>

          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <Button
              variant="outline"
              className="h-16 sm:h-20 flex flex-col items-center justify-center gap-1 sm:gap-2 rounded-xl bg-slate-100/50 dark:bg-slate-800/50 backdrop-blur-sm border-slate-200 dark:border-slate-700"
              onClick={() => setActiveInputMethod("barcode")}
            >
              <Scan className="text-violet-500" size={18} />
              <span className="text-sm">Scan Barcode</span>
            </Button>

            <Button
              variant="outline"
              className="h-16 sm:h-20 flex flex-col items-center justify-center gap-1 sm:gap-2 rounded-xl bg-slate-100/50 dark:bg-slate-800/50 backdrop-blur-sm border-slate-200 dark:border-slate-700"
              onClick={() => setActiveInputMethod("manual")}
            >
              <Search className="text-violet-500" size={18} />
              <span className="text-sm">Manual Entry</span>
            </Button>
          </div>

          {activeInputMethod === "barcode" && (
            <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-slate-200 dark:border-slate-700 mt-4 animate-in fade-in slide-in-from-bottom-5 duration-300">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">Barcode Scanner</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => setActiveInputMethod(null)}
                >
                  <X size={16} />
                </Button>
              </div>

              <div className="aspect-video bg-slate-100 dark:bg-slate-700 rounded-lg overflow-hidden flex items-center justify-center mb-4">
                <div className="text-center p-4 sm:p-6">
                  <Scan className="mx-auto mb-3 text-slate-400" size={36} />
                  <p className="text-slate-500 dark:text-slate-400 mb-3 text-sm">Position barcode within the frame</p>
                  <Button
                    className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                    onClick={simulateBarcodeScanning}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {scanFeedback || "Scanning..."}
                      </>
                    ) : (
                      "Start Scanning"
                    )}
                  </Button>
                </div>
              </div>

              {error && (
                <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3 mb-4 flex items-start gap-2">
                  <AlertTriangle size={16} className="text-red-500 mt-0.5 flex-shrink-0" />
                  <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 border-slate-200 dark:border-slate-700"
                  onClick={() => setActiveInputMethod(null)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                  onClick={simulateBarcodeScanning}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Scanning...
                    </>
                  ) : (
                    "Scan"
                  )}
                </Button>
              </div>
            </div>
          )}

          {activeInputMethod === "manual" && (
            <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-slate-200 dark:border-slate-700 mt-4 animate-in fade-in slide-in-from-bottom-5 duration-300">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">Food Search</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => setActiveInputMethod(null)}
                >
                  <X size={16} />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search for food (e.g., chicken breast, apple)"
                    className="w-full h-11 pl-10 pr-4 rounded-xl bg-slate-100 dark:bg-slate-700 border-0 focus:ring-2 focus:ring-violet-500"
                    value={foodInput}
                    onChange={(e) => setFoodInput(e.target.value)}
                  />
                  <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>

                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3 flex items-start gap-2">
                    <AlertTriangle size={16} className="text-red-500 mt-0.5 flex-shrink-0" />
                    <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
                  </div>
                )}

                <div>
                  <div className="text-sm text-slate-500 dark:text-slate-400 mb-2">Recent searches</div>
                  <div className="grid grid-cols-2 gap-2 sm:gap-3">
                    {recentSearches.map((item, index) => (
                      <div
                        key={index}
                        className="bg-slate-100 dark:bg-slate-700 rounded-xl p-3 cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
                        onClick={() => {
                          setFoodInput(item)
                          analyzeFoodFromText(item)
                        }}
                      >
                        <div className="font-medium text-sm">{item}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">Tap to analyze</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 mt-2">
                  <Button
                    variant="outline"
                    className="flex-1 border-slate-200 dark:border-slate-700"
                    onClick={() => setActiveInputMethod(null)}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                    onClick={() => analyzeFoodFromText()}
                    disabled={isLoading || !foodInput.trim()}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      "Analyze Food"
                    )}
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/30 rounded-xl p-3 sm:p-4 mt-4 sm:mt-6">
            <div className="flex items-start gap-2 sm:gap-3">
              <AlertTriangle size={18} className="text-amber-500 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-medium text-amber-800 dark:text-amber-400 text-sm">AI Accuracy Notice</h3>
                <p className="text-xs sm:text-sm text-amber-700 dark:text-amber-300/80 mt-1">
                  Our AI provides ~90% accuracy for most foods. Complex or mixed dishes like smoothies and soups may
                  have lower accuracy.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function NutrientCard({ label, value, percentage, color }) {
  return (
    <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-2 sm:p-3">
      <div className="text-center mb-1 sm:mb-2">
        <div className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{label}</div>
        <div className="font-bold text-base sm:text-lg">{value}</div>
      </div>
      <div className="h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${color} rounded-full transition-all duration-500`}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
    </div>
  )
}

