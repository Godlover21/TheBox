"use client"

import { useState, useEffect } from "react"
// Remove framer-motion imports
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  ReferenceLine,
} from "recharts"
import { Loader2 } from "lucide-react"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("progress")
  const [dietPlanStep, setDietPlanStep] = useState(0)
  const [showWeightModal, setShowWeightModal] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [dietPlan, setDietPlan] = useState(null)
  const [weightInsights, setWeightInsights] = useState(null)
  const [error, setError] = useState("")

  // Form state
  const [goal, setGoal] = useState("lose-weight")
  const [restrictions, setRestrictions] = useState("none")
  const [activityLevel, setActivityLevel] = useState("moderate")
  const [newWeight, setNewWeight] = useState(178)

  // Add isDarkMode for chart styling
  const isDarkMode = document.documentElement.classList.contains("dark")

  const weightData = [
    { day: "Mon", weight: 185 },
    { day: "Tue", weight: 184 },
    { day: "Wed", weight: 183 },
    { day: "Thu", weight: 182 },
    { day: "Fri", weight: 181 },
    { day: "Sat", weight: 180 },
    { day: "Sun", weight: 178 },
  ]

  // Add this function near the top of the ProfilePage component:
  const getDefaultWeightInsights = () => {
    return {
      progress: {
        weightLost: 7,
        percentageToGoal: 35,
        weeklyRate: 1,
      },
      analysis: "You're making good progress toward your goal weight.",
      recommendations: [
        "Continue with your current diet plan",
        "Try to increase water intake",
        "Add more strength training to your routine",
      ],
      projectedTimeToGoal: 13,
      healthStatus: "Your weight loss rate is healthy and sustainable",
    }
  }

  // Get weight insights on component mount
  useEffect(() => {
    getWeightInsights()
  }, [])

  // Then update the getWeightInsights function:
  const getWeightInsights = async () => {
    setIsLoading(true)
    try {
      // Try to fetch data from the API
      const response = await fetch("/api/weight-insights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          startWeight: 185,
          currentWeight: 178,
          goalWeight: 165,
          timeFrame: 7, // days
        }),
      })

      // If the API call fails, use fallback data
      if (!response.ok) {
        console.warn(`API returned status: ${response.status}`)
        setWeightInsights(getDefaultWeightInsights())
        setIsLoading(false)
        return
      }

      // Try to parse the response
      try {
        const result = await response.json()

        // If the data property is missing, use fallback data
        if (!result.data) {
          console.warn("API response missing data property")
          setWeightInsights(getDefaultWeightInsights())
          setIsLoading(false)
          return
        }

        // Set the weight insights from the API response
        setWeightInsights(result.data)
      } catch (parseError) {
        console.error("Error parsing API response:", parseError)
        setWeightInsights(getDefaultWeightInsights())
      }
    } catch (error) {
      console.error("Error getting weight insights:", error)
      // Always use fallback data in case of any error
      setWeightInsights(getDefaultWeightInsights())
    } finally {
      setIsLoading(false)
    }
  }

  const generateDietPlan = async () => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/api/diet-plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          goal,
          restrictions,
          activityLevel,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate diet plan")
      }

      const result = await response.json()
      setDietPlan(result.data)
      setDietPlanStep(2) // Move to results step
      setIsLoading(false)
    } catch (error) {
      console.error("Error generating diet plan:", error)
      setError("Failed to generate diet plan. Please try again.")
      setIsLoading(false)
    }
  }

  const logWeight = async () => {
    setIsLoading(true)

    try {
      // In a real app, you would save this to a database
      // For now, we'll just update the insights
      const response = await fetch("/api/weight-insights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          startWeight: 185,
          currentWeight: newWeight,
          goalWeight: 165,
          timeFrame: 7, // days
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update weight")
      }

      const result = await response.json()
      setWeightInsights(result.data)
      setShowWeightModal(false)
      setIsLoading(false)
    } catch (error) {
      console.error("Error logging weight:", error)
      setError("Failed to log weight. Please try again.")
      setIsLoading(false)
    }
  }

  const nextStep = () => {
    if (dietPlanStep === 1) {
      generateDietPlan()
    } else {
      setDietPlanStep((prev) => prev + 1)
    }
  }

  const prevStep = () => {
    setDietPlanStep((prev) => Math.max(0, prev - 1))
  }

  return (
    <div className="flex flex-col h-full overflow-auto pb-24 px-5 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Profile</h1>
        <p className="text-slate-500 dark:text-slate-400">Track your progress and goals</p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className="grid grid-cols-3 h-12 bg-slate-100 dark:bg-slate-800/50 rounded-xl p-1">
          <TabsTrigger
            value="progress"
            className={cn(
              "rounded-lg text-sm",
              activeTab === "progress"
                ? "bg-white dark:bg-slate-700 shadow-sm"
                : "hover:bg-slate-200/50 dark:hover:bg-slate-700/30",
            )}
          >
            Progress
          </TabsTrigger>
          <TabsTrigger
            value="diet-plan"
            className={cn(
              "rounded-lg text-sm",
              activeTab === "diet-plan"
                ? "bg-white dark:bg-slate-700 shadow-sm"
                : "hover:bg-slate-200/50 dark:hover:bg-slate-700/30",
            )}
          >
            Diet Plan
          </TabsTrigger>
          <TabsTrigger
            value="settings"
            className={cn(
              "rounded-lg text-sm",
              activeTab === "settings"
                ? "bg-white dark:bg-slate-700 shadow-sm"
                : "hover:bg-slate-200/50 dark:hover:bg-slate-700/30",
            )}
          >
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="progress" className="mt-6 space-y-6 data-[state=inactive]:hidden">
          <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-700">
            <h2 className="text-lg font-bold mb-4">Weekly Summary</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Calories Goal</span>
                  <span className="text-sm font-medium">1,750 / 2,500 avg</span>
                </div>
                <Progress value={70} className="h-2 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full" />
                </Progress>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Water Intake</span>
                  <span className="text-sm font-medium">1.8L / 2.5L avg</span>
                </div>
                <Progress value={72} className="h-2 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full" />
                </Progress>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Protein Goal</span>
                  <span className="text-sm font-medium">110g / 120g avg</span>
                </div>
                <Progress value={91.7} className="h-2 bg-slate-200 dark:bg-slate-700">
                  <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                </Progress>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-700">
            <h2 className="text-lg font-bold mb-4">Weight Tracking</h2>
            {isLoading && !weightInsights ? (
              <div className="flex justify-center items-center h-60">
                <Loader2 className="h-8 w-8 animate-spin text-violet-500" />
              </div>
            ) : (
              <div className="h-60 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={weightData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                    <defs>
                      <linearGradient id="weightGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="weightLine" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="5%" stopColor="#8b5cf6" />
                        <stop offset="95%" stopColor="#6366f1" />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "#334155" : "#e2e8f0"} />
                    <XAxis dataKey="day" stroke={isDarkMode ? "#94a3b8" : "#64748b"} tick={{ fontSize: 10 }} />
                    <YAxis
                      domain={["dataMin - 2", "dataMax + 2"]}
                      stroke={isDarkMode ? "#94a3b8" : "#64748b"}
                      tick={{ fontSize: 10 }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: isDarkMode ? "rgba(30, 41, 59, 0.8)" : "rgba(255, 255, 255, 0.8)",
                        borderRadius: "12px",
                        border: "none",
                        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
                        padding: "8px 12px",
                      }}
                      itemStyle={{
                        color: isDarkMode ? "#f8fafc" : "#0f172a",
                        fontSize: "12px",
                      }}
                      labelStyle={{
                        color: isDarkMode ? "#cbd5e1" : "#334155",
                        fontWeight: "bold",
                        marginBottom: "4px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="weight"
                      stroke="url(#weightLine)"
                      fillOpacity={1}
                      fill="url(#weightGradient)"
                    />
                    <Line
                      type="monotone"
                      dataKey="weight"
                      stroke="url(#weightLine)"
                      strokeWidth={3}
                      dot={{ r: 6, fill: "#8b5cf6", strokeWidth: 2, stroke: isDarkMode ? "#1e293b" : "#ffffff" }}
                      activeDot={{ r: 8, fill: "#8b5cf6", strokeWidth: 2, stroke: isDarkMode ? "#1e293b" : "#ffffff" }}
                    />
                    {/* Add reference line for goal weight */}
                    <ReferenceLine
                      y={165}
                      stroke="#10b981"
                      strokeDasharray="3 3"
                      label={{
                        value: "Goal",
                        position: "insideBottomRight",
                        fill: isDarkMode ? "#10b981" : "#059669",
                        fontSize: 10,
                      }}
                    />
                    {/* Add reference line for starting weight */}
                    <ReferenceLine
                      y={185}
                      stroke="#f97316"
                      strokeDasharray="3 3"
                      label={{
                        value: "Start",
                        position: "insideTopRight",
                        fill: isDarkMode ? "#f97316" : "#ea580c",
                        fontSize: 10,
                      }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {weightInsights && (
              <>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-3">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Weight Loss</div>
                    <div className="font-bold text-lg text-green-600 dark:text-green-400">
                      {weightInsights.progress.weightLost} lbs
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Last 7 days</div>
                  </div>
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-3">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Weekly Rate</div>
                    <div className="font-bold text-lg text-violet-600 dark:text-violet-400">
                      {weightInsights.progress.weeklyRate} lbs
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">per week</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-2 text-center">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Starting</div>
                    <div className="font-bold text-sm">185 lbs</div>
                  </div>
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-2 text-center">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Current</div>
                    <div className="font-bold text-sm">178 lbs</div>
                  </div>
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-2 text-center">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Goal</div>
                    <div className="font-bold text-sm">165 lbs</div>
                  </div>
                </div>
              </>
            )}

            <Button
              className="w-full mt-3 h-10 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white text-sm"
              onClick={() => setShowWeightModal(true)}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                "Log Today's Weight"
              )}
            </Button>
          </div>

          {/* Add this new statistical component after the weight tracking section */}
          <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-700 mt-4">
            <h2 className="text-lg font-bold mb-4">Weight Statistics</h2>

            {weightInsights ? (
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Progress to Goal</span>
                    <span className="text-sm font-medium">{weightInsights.progress.percentageToGoal}% Complete</span>
                  </div>
                  <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full"
                      style={{ width: `${weightInsights.progress.percentageToGoal}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-1 text-xs text-slate-500">
                    <span>Start: 185 lbs</span>
                    <span>Current: 178 lbs</span>
                    <span>Goal: 165 lbs</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">BMI</div>
                        <div className="font-bold">24.2</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-green-600 dark:text-green-400"
                        >
                          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                          <path d="m9 11 3 3L22 4" />
                        </svg>
                      </div>
                    </div>
                    <div className="text-xs text-green-600 dark:text-green-400 mt-1">{weightInsights.healthStatus}</div>
                  </div>

                  <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">Projected</div>
                        <div className="font-bold">{weightInsights.projectedTimeToGoal} weeks</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-violet-600 dark:text-violet-400"
                        >
                          <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                          <line x1="16" x2="16" y1="2" y2="6" />
                          <line x1="8" x2="8" y1="2" y2="6" />
                          <line x1="3" x2="21" y1="10" y2="10" />
                          <path d="m9 16 2 2 4-4" />
                        </svg>
                      </div>
                    </div>
                    <div className="text-xs text-violet-600 dark:text-violet-400 mt-1">Until Goal Weight</div>
                  </div>
                </div>

                {weightInsights.recommendations && weightInsights.recommendations.length > 0 && (
                  <div className="bg-violet-50 dark:bg-violet-900/20 rounded-xl p-4 border border-violet-100 dark:border-violet-800/30">
                    <h3 className="font-medium text-violet-800 dark:text-violet-300 mb-2">AI Recommendations</h3>
                    <ul className="space-y-1">
                      {weightInsights.recommendations.map((rec, index) => (
                        <li
                          key={index}
                          className="text-sm text-violet-700 dark:text-violet-400/80 flex items-start gap-2"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="mt-0.5 flex-shrink-0 text-violet-500"
                          >
                            <polyline points="9 11 12 14 22 4"></polyline>
                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                          </svg>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-violet-500" />
              </div>
            )}
          </div>

          {showWeightModal && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-md shadow-xl animate-in fade-in zoom-in duration-300">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Log Weight</h2>
                  <button
                    onClick={() => setShowWeightModal(false)}
                    className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 dark:bg-slate-700"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </button>
                </div>

                <div className="mb-6">
                  <div className="flex justify-center mb-4">
                    <div className="w-24 h-24 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="40"
                        height="40"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-violet-500"
                      >
                        <path d="M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973" />
                        <path d="m9 20 3-3-3-3" />
                        <path d="m6 16-3-3 3-3" />
                      </svg>
                    </div>
                  </div>

                  <div className="relative mb-6">
                    <input
                      type="number"
                      className="w-full h-16 text-center text-3xl font-bold bg-slate-100 dark:bg-slate-700 rounded-xl border-0 focus:ring-2 focus:ring-violet-500"
                      value={newWeight}
                      onChange={(e) => setNewWeight(Number(e.target.value))}
                    />
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 text-lg text-slate-500 dark:text-slate-400">
                      lbs
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 h-12 rounded-xl border-slate-200 dark:border-slate-700"
                      onClick={() => setShowWeightModal(false)}
                      disabled={isLoading}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="flex-1 h-12 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                      onClick={logWeight}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        "Save Weight"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="diet-plan" className="mt-6 data-[state=inactive]:hidden">
          <div>
            {dietPlanStep === 0 && (
              <div key="step0" className="animate-in fade-in slide-in-from-bottom-5 duration-300">
                <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
                  <div className="text-center mb-6">
                    <div className="w-20 h-20 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center mx-auto mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="32"
                        height="32"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-violet-600 dark:text-violet-400"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Create Your Diet Plan</h2>
                    <p className="text-slate-500 dark:text-slate-400 mb-6">
                      Our AI will create a personalized diet plan based on your goals, preferences, and lifestyle.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-violet-50 dark:bg-violet-900/20 rounded-xl p-4 border border-violet-100 dark:border-violet-800/30">
                      <div className="flex items-start gap-3">
                        <div className="mt-1 text-violet-600 dark:text-violet-400">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M2.27 21.7s9.87-3.5 12.73-6.36a4.5 4.5 0 0 0-6.36-6.37C5.77 11.84 2.27 21.7 2.27 21.7zM15.42 15.42l6.37-6.37a4.5 4.5 0 0 0-6.37-6.36l-6.36 6.36" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-medium text-violet-800 dark:text-violet-300">Personalized Nutrition</h3>
                          <p className="text-sm text-violet-700 dark:text-violet-400/80 mt-1">
                            Get a diet plan tailored to your body type, goals, and food preferences.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-xl p-4 border border-indigo-100 dark:border-indigo-800/30">
                      <div className="flex items-start gap-3">
                        <div className="mt-1 text-indigo-600 dark:text-indigo-400">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z" />
                            <path d="M10 2c1 .5 2 2 2 5" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-medium text-indigo-800 dark:text-indigo-300">
                            AI-Powered Meal Suggestions
                          </h3>
                          <p className="text-sm text-indigo-700 dark:text-indigo-400/80 mt-1">
                            Get meal ideas based on your nutritional needs and dietary restrictions.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 border border-blue-100 dark:border-blue-800/30">
                      <div className="flex items-start gap-3">
                        <div className="mt-1 text-blue-600 dark:text-blue-400">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                            <path d="m9 12 2 2 4-4" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-medium text-blue-800 dark:text-blue-300">Adaptive Planning</h3>
                          <p className="text-sm text-blue-700 dark:text-blue-400/80 mt-1">
                            Your plan adjusts based on your progress and feedback for optimal results.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={nextStep}
                    className="w-full mt-6 h-14 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                  >
                    Start Questionnaire
                  </Button>
                </div>
              </div>
            )}

            {dietPlanStep === 1 && (
              <div key="step1" className="animate-in fade-in slide-in-from-bottom-5 duration-300">
                <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-bold">Diet Preferences</h2>
                      <div className="text-sm font-medium text-violet-600 dark:text-violet-400">Step 1 of 3</div>
                    </div>
                    <div className="w-full h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-1/3 bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full" />
                    </div>
                  </div>

                  {error && (
                    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800/30 rounded-xl p-3 mb-4">
                      <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
                    </div>
                  )}

                  <div className="space-y-5">
                    <div>
                      <label className="text-sm font-medium mb-2 block">What is your goal?</label>
                      <Select value={goal} onValueChange={setGoal}>
                        <SelectTrigger className="w-full h-14 rounded-xl bg-slate-100 dark:bg-slate-800 border-0">
                          <SelectValue placeholder="Select a goal" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lose-weight">Lose Weight</SelectItem>
                          <SelectItem value="maintain">Maintain Weight</SelectItem>
                          <SelectItem value="gain-muscle">Gain Muscle</SelectItem>
                          <SelectItem value="improve-health">Improve Overall Health</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Dietary restrictions?</label>
                      <Select value={restrictions} onValueChange={setRestrictions}>
                        <SelectTrigger className="w-full h-14 rounded-xl bg-slate-100 dark:bg-slate-800 border-0">
                          <SelectValue placeholder="Select restrictions" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="vegetarian">Vegetarian</SelectItem>
                          <SelectItem value="vegan">Vegan</SelectItem>
                          <SelectItem value="gluten-free">Gluten Free</SelectItem>
                          <SelectItem value="dairy-free">Dairy Free</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Activity level?</label>
                      <Select value={activityLevel} onValueChange={setActivityLevel}>
                        <SelectTrigger className="w-full h-14 rounded-xl bg-slate-100 dark:bg-slate-800 border-0">
                          <SelectValue placeholder="Select activity level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                          <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                          <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                          <SelectItem value="active">Very Active (6-7 days/week)</SelectItem>
                          <SelectItem value="extreme">Extremely Active (physical job or training)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-8">
                    <Button
                      onClick={prevStep}
                      variant="outline"
                      className="flex-1 h-14 rounded-xl border-slate-200 dark:border-slate-700"
                      disabled={isLoading}
                    >
                      Back
                    </Button>
                    <Button
                      onClick={nextStep}
                      className="flex-1 h-14 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        "Generate Plan"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {dietPlanStep === 2 && (
              <div key="step2" className="animate-in fade-in slide-in-from-bottom-5 duration-300">
                <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-bold">Your Personalized Diet Plan</h2>
                      <div className="text-sm font-medium text-violet-600 dark:text-violet-400">Complete!</div>
                    </div>
                    <div className="w-full h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-full bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full" />
                    </div>
                  </div>

                  {isLoading ? (
                    <div className="flex flex-col items-center justify-center py-12">
                      <Loader2 className="h-12 w-12 animate-spin text-violet-500 mb-4" />
                      <p className="text-slate-500 dark:text-slate-400">Generating your personalized diet plan...</p>
                    </div>
                  ) : dietPlan ? (
                    <>
                      <div className="bg-gradient-to-br from-violet-50 to-indigo-50 dark:from-violet-900/20 dark:to-indigo-900/20 rounded-xl p-5 mb-6 border border-violet-100 dark:border-violet-800/30">
                        <h3 className="font-bold text-lg text-violet-800 dark:text-violet-300 mb-2">
                          {dietPlan.planName}
                        </h3>
                        <p className="text-sm text-violet-700 dark:text-violet-400/80">{dietPlan.description}</p>
                      </div>

                      <div className="mb-6">
                        <h3 className="font-bold mb-3">Daily Macronutrient Targets</h3>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4 text-center">
                            <div className="text-sm text-slate-500 dark:text-slate-400">Calories</div>
                            <div className="font-bold text-xl">{dietPlan.dailyCalories}</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">kcal</div>
                          </div>
                          <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4 text-center">
                            <div className="text-sm text-slate-500 dark:text-slate-400">Protein</div>
                            <div className="font-bold text-xl">{dietPlan.macros.protein.grams}g</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {dietPlan.macros.protein.percentage}%
                            </div>
                          </div>
                          <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4 text-center">
                            <div className="text-sm text-slate-500 dark:text-slate-400">Carbs</div>
                            <div className="font-bold text-xl">{dietPlan.macros.carbs.grams}g</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {dietPlan.macros.carbs.percentage}%
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3 mt-3">
                          <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4 text-center">
                            <div className="text-sm text-slate-500 dark:text-slate-400">Fat</div>
                            <div className="font-bold text-xl">{dietPlan.macros.fat.grams}g</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {dietPlan.macros.fat.percentage}%
                            </div>
                          </div>
                          <div className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4 text-center">
                            <div className="text-sm text-slate-500 dark:text-slate-400">Fiber</div>
                            <div className="font-bold text-xl">{dietPlan.macros.fiber}g</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">daily</div>
                          </div>
                        </div>
                      </div>

                      <div className="mb-6">
                        <h3 className="font-bold mb-3">Sample Meal Plan</h3>
                        <div className="space-y-3">
                          {dietPlan.meals.map((meal, index) => (
                            <div key={index} className="bg-slate-100 dark:bg-slate-700/30 rounded-xl p-4">
                              <div className="font-medium">
                                {meal.name} ({meal.time})
                              </div>
                              <div className="text-sm text-slate-600 dark:text-slate-300">{meal.description}</div>
                              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                {meal.nutrition.calories} calories | {meal.nutrition.protein}g protein |{" "}
                                {meal.nutrition.carbs}g carbs | {meal.nutrition.fat}g fat
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/30 rounded-xl p-4 mb-6">
                      <p className="text-amber-700 dark:text-amber-400">
                        There was an error generating your diet plan. Please try again.
                      </p>
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button
                      onClick={prevStep}
                      variant="outline"
                      className="flex-1 h-14 rounded-xl border-slate-200 dark:border-slate-700"
                    >
                      Back
                    </Button>
                    <Button className="flex-1 h-14 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white">
                      Save Plan
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="mt-6 data-[state=inactive]:hidden">
          <div className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
            <h2 className="text-xl font-bold mb-6">App Settings</h2>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Dark Mode</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">Switch between light and dark themes</div>
                </div>
                <div className="h-7 w-12 bg-slate-200 dark:bg-slate-700 rounded-full relative">
                  <div className="h-5 w-5 bg-white rounded-full absolute top-1 right-1 shadow-sm"></div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Notifications</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">Reminders and alerts</div>
                </div>
                <div className="h-7 w-12 bg-violet-500 rounded-full relative">
                  <div className="h-5 w-5 bg-white rounded-full absolute top-1 right-1 shadow-sm"></div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Units</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">Measurement system</div>
                </div>
                <Select defaultValue="imperial">
                  <SelectTrigger className="w-32 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 border-0">
                    <SelectValue placeholder="Select units" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="imperial">Imperial</SelectItem>
                    <SelectItem value="metric">Metric</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Language</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">App language</div>
                </div>
                <Select defaultValue="english">
                  <SelectTrigger className="w-32 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 border-0">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                    <SelectItem value="german">German</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-2">
                <Button className="w-full h-14 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white">
                  Save Settings
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

