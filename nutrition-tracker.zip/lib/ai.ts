import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Update the analyzeFoodNutrition function to handle all three input methods:

// Function to analyze food from image or description
export async function analyzeFoodNutrition(input: string, isImage = false, isBarcode = false) {
  let prompt = ""

  if (isImage) {
    prompt = `Analyze this food image and provide detailed nutritional information in JSON format. Include: name, calories, protein, carbs, fat, healthScore (1-10), and ingredients list. The image description is: ${input}`
  } else if (isBarcode) {
    prompt = `Analyze this barcode scan result and provide detailed nutritional information in JSON format. Include: name, calories, protein, carbs, fat, healthScore (1-10), and ingredients list. The barcode scan returned: ${input}`
  } else {
    prompt = `Analyze this food description and provide detailed nutritional information in JSON format. Include: name, calories, protein, carbs, fat, healthScore (1-10), and ingredients list. The food is: ${input}`
  }

  const systemPrompt = `You are a nutrition expert AI. Provide accurate nutritional information for foods in JSON format. 
Always return valid JSON with the following structure:
{
  "name": "Food Name",
  "calories": number,
  "protein": number,
  "carbs": number,
  "fat": number,
  "healthScore": number (1-10),
  "ingredients": ["ingredient1", "ingredient2", ...],
  "servingSize": "standard serving size",
  "allergens": ["allergen1", "allergen2", ...] (if applicable, otherwise empty array)
}`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
      temperature: 0.3, // Lower temperature for more consistent results
      maxTokens: 800, // Ensure we have enough tokens for detailed response
    })

    // Parse and validate the response
    const parsedData = JSON.parse(text)

    // Ensure all required fields exist
    const requiredFields = ["name", "calories", "protein", "carbs", "fat", "healthScore", "ingredients"]
    for (const field of requiredFields) {
      if (!(field in parsedData)) {
        throw new Error(`Missing required field: ${field}`)
      }
    }

    return parsedData
  } catch (error) {
    console.error("Error analyzing food:", error)
    // Return fallback data with error indication
    return {
      name: input.length > 30 ? `${input.substring(0, 30)}...` : input,
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      healthScore: 0,
      ingredients: ["Unknown"],
      error: error.message,
    }
  }
}

// Function to generate personalized diet plan
export async function generateDietPlan(goal: string, restrictions: string, activityLevel: string) {
  const prompt = `Create a personalized diet plan based on the following information:
  - Goal: ${goal}
  - Dietary restrictions: ${restrictions}
  - Activity level: ${activityLevel}
  
  Provide a comprehensive plan with daily calorie targets, macronutrient breakdown, and sample meals.`

  const systemPrompt = `You are a certified nutritionist and diet expert. Create personalized diet plans based on user goals, 
  restrictions, and activity levels. Return the response in JSON format with the following structure:
  {
    "planName": "Name of the diet plan",
    "description": "Brief description of the plan",
    "dailyCalories": number,
    "macros": {
      "protein": { "grams": number, "percentage": number },
      "carbs": { "grams": number, "percentage": number },
      "fat": { "grams": number, "percentage": number },
      "fiber": number
    },
    "meals": [
      {
        "name": "Meal name",
        "time": "Suggested time",
        "description": "Brief description",
        "nutrition": { "calories": number, "protein": number, "carbs": number, "fat": number }
      }
    ]
  }`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
    })

    return JSON.parse(text)
  } catch (error) {
    console.error("Error generating diet plan:", error)
    return null
  }
}

// Function to get weight loss insights
export async function getWeightInsights(
  startWeight: number,
  currentWeight: number,
  goalWeight: number,
  timeFrame: number,
) {
  const prompt = `Analyze this weight loss journey and provide insights:
  - Starting weight: ${startWeight} lbs
  - Current weight: ${currentWeight} lbs
  - Goal weight: ${goalWeight} lbs
  - Time frame: ${timeFrame} days
  
  Provide insights on progress, rate of weight loss, and recommendations.`

  const systemPrompt = `You are a weight management expert. Analyze weight data and provide helpful insights and recommendations.
  Return the response in JSON format with the following structure:
  {
    "progress": {
      "weightLost": number,
      "percentageToGoal": number,
      "weeklyRate": number
    },
    "analysis": "Detailed analysis of the weight loss progress",
    "recommendations": ["recommendation1", "recommendation2", ...],
    "projectedTimeToGoal": number (in weeks),
    "healthStatus": "Brief statement about the health implications"
  }`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
      temperature: 0.3, // Lower temperature for more consistent results
      maxTokens: 800, // Ensure we have enough tokens for detailed response
    })

    // Parse and validate the response
    const parsedData = JSON.parse(text)

    // Ensure all required fields exist
    const requiredFields = ["progress", "analysis", "recommendations", "projectedTimeToGoal", "healthStatus"]
    for (const field of requiredFields) {
      if (!(field in parsedData)) {
        throw new Error(`Missing required field: ${field}`)
      }
    }

    // Validate progress object
    const progressFields = ["weightLost", "percentageToGoal", "weeklyRate"]
    for (const field of progressFields) {
      if (!(field in parsedData.progress)) {
        throw new Error(`Missing progress field: ${field}`)
      }
    }

    return parsedData
  } catch (error) {
    console.error("Error getting weight insights:", error)

    // Return fallback data with valid structure
    return {
      progress: {
        weightLost: startWeight - currentWeight,
        percentageToGoal: Math.round(((startWeight - currentWeight) / (startWeight - goalWeight)) * 100),
        weeklyRate: ((startWeight - currentWeight) / timeFrame) * 7,
      },
      analysis: "Based on your current progress, you're on track to reach your goal weight.",
      recommendations: [
        "Continue with your current diet plan",
        "Try to increase water intake",
        "Add more strength training to your routine",
      ],
      projectedTimeToGoal: Math.round((currentWeight - goalWeight) / ((startWeight - currentWeight) / timeFrame) / 7),
      healthStatus: "Your weight loss rate is healthy and sustainable",
    }
  }
}

// Function to suggest meals based on remaining macros
export async function suggestMeals(
  remainingCalories: number,
  remainingProtein: number,
  remainingCarbs: number,
  remainingFat: number,
  preferences = "",
) {
  const prompt = `Suggest meals based on these remaining daily nutritional targets:
  - Calories: ${remainingCalories} kcal
  - Protein: ${remainingProtein}g
  - Carbs: ${remainingCarbs}g
  - Fat: ${remainingFat}g
  ${preferences ? `- Preferences/restrictions: ${preferences}` : ""}
  
  Suggest 3 meal options that would help meet these remaining targets.`

  const systemPrompt = `You are a meal planning expert. Suggest meals that help users meet their remaining nutritional targets for the day.
  Return the response in JSON format with the following structure:
  {
    "suggestions": [
      {
        "name": "Meal name",
        "description": "Brief description",
        "nutrition": { "calories": number, "protein": number, "carbs": number, "fat": number },
        "ingredients": ["ingredient1", "ingredient2", ...],
        "preparationTime": number (in minutes)
      }
    ]
  }`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
    })

    return JSON.parse(text)
  } catch (error) {
    console.error("Error suggesting meals:", error)
    return null
  }
}

// Function to provide nutritional advice
export async function getNutritionalAdvice(question: string) {
  const systemPrompt = `You are a certified nutritionist providing evidence-based nutritional advice. 
  Keep responses concise, accurate, and helpful. If you don't know something, say so rather than providing potentially incorrect information.`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: question,
    })

    return text
  } catch (error) {
    console.error("Error getting nutritional advice:", error)
    return "Sorry, I couldn't process your question at the moment. Please try again later."
  }
}

