import { type NextRequest, NextResponse } from "next/server"
import { getNutritionalAdvice } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { question } = await request.json()

    if (!question) {
      return NextResponse.json({ error: "Missing question parameter" }, { status: 400 })
    }

    const advice = await getNutritionalAdvice(question)

    return NextResponse.json({ data: advice })
  } catch (error) {
    console.error("Error in chat API route:", error)
    return NextResponse.json({ error: "Failed to get nutritional advice" }, { status: 500 })
  }
}

