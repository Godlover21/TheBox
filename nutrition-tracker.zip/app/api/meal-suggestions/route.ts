import { type NextRequest, NextResponse } from "next/server"
import { suggestMeals } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { remainingCalories, remainingProtein, remainingCarbs, remainingFat, preferences } = await request.json()

    if (!remainingCalories) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    const suggestions = await suggestMeals(
      remainingCalories,
      remainingProtein,
      remainingCarbs,
      remainingFat,
      preferences,
    )

    return NextResponse.json({ data: suggestions })
  } catch (error) {
    console.error("Error in meal-suggestions API route:", error)
    return NextResponse.json({ error: "Failed to get meal suggestions" }, { status: 500 })
  }
}

