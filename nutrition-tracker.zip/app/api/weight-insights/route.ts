import { type NextRequest, NextResponse } from "next/server"
import { getWeightInsights } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { startWeight, currentWeight, goalWeight, timeFrame } = await request.json()

    if (!startWeight || !currentWeight || !goalWeight) {
      return NextResponse.json(
        {
          error: "Missing required parameters",
          data: getFallbackWeightInsights(startWeight || 185, currentWeight || 178, goalWeight || 165, timeFrame || 7),
        },
        { status: 400 },
      )
    }

    try {
      const insights = await getWeightInsights(startWeight, currentWeight, goalWeight, timeFrame)
      return NextResponse.json({ data: insights })
    } catch (aiError) {
      console.error("AI processing error:", aiError)
      // Return fallback data even when AI processing fails
      return NextResponse.json({
        data: getFallbackWeightInsights(startWeight, currentWeight, goalWeight, timeFrame),
        warning: "Used fallback data due to AI processing error",
      })
    }
  } catch (error) {
    console.error("Error in weight-insights API route:", error)
    // Return fallback data with a 200 status to prevent UI errors
    return NextResponse.json(
      {
        data: getFallbackWeightInsights(185, 178, 165, 7),
        error: "Failed to process request, using fallback data",
      },
      { status: 200 },
    )
  }
}

// Fallback function to generate weight insights when the AI fails
function getFallbackWeightInsights(startWeight: number, currentWeight: number, goalWeight: number, timeFrame: number) {
  const weightLost = startWeight - currentWeight
  const totalToLose = startWeight - goalWeight
  const percentageToGoal = Math.round((weightLost / totalToLose) * 100)
  const weeklyRate = (weightLost / timeFrame) * 7
  const weeksToGoal = Math.round((currentWeight - goalWeight) / weeklyRate)

  return {
    progress: {
      weightLost,
      percentageToGoal,
      weeklyRate: Number.parseFloat(weeklyRate.toFixed(1)),
    },
    analysis: "Based on your current progress, you're on track to reach your goal weight.",
    recommendations: [
      "Continue with your current diet plan",
      "Try to increase water intake",
      "Add more strength training to your routine",
    ],
    projectedTimeToGoal: weeksToGoal > 0 ? weeksToGoal : 1,
    healthStatus: "Your weight loss rate is healthy and sustainable",
  }
}

