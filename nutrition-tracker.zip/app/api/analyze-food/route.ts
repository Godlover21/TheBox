import { type NextRequest, NextResponse } from "next/server"
import { analyzeFoodNutrition } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { input, isImage = false } = await request.json()

    if (!input) {
      return NextResponse.json({ error: "Missing input parameter" }, { status: 400 })
    }

    const nutritionData = await analyzeFoodNutrition(input, isImage)

    return NextResponse.json({ data: nutritionData })
  } catch (error) {
    console.error("Error in analyze-food API route:", error)
    return NextResponse.json({ error: "Failed to analyze food" }, { status: 500 })
  }
}

