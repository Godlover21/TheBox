import { type NextRequest, NextResponse } from "next/server"
import { generateDietPlan } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { goal, restrictions, activityLevel } = await request.json()

    if (!goal || !activityLevel) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    const dietPlan = await generateDietPlan(goal, restrictions, activityLevel)

    return NextResponse.json({ data: dietPlan })
  } catch (error) {
    console.error("Error in diet-plan API route:", error)
    return NextResponse.json({ error: "Failed to generate diet plan" }, { status: 500 })
  }
}

