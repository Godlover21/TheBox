"use client"

import { useState, useEffect } from "react"
import HomePage from "@/components/home-page"
import ScanPage from "@/components/scan-page"
import ProfilePage from "@/components/profile-page"
import ChatAssistant from "@/components/chat-assistant"
import { cn } from "@/lib/utils"

export default function Home() {
  const [activeTab, setActiveTab] = useState("home")
  const [isDarkMode, setIsDarkMode] = useState(true)

  useEffect(() => {
    // Apply dark mode class to document
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDarkMode])

  return (
    <div
      className={cn(
        "flex flex-col h-screen w-full overflow-hidden bg-gradient-to-br from-slate-50 to-white dark:from-slate-950 dark:to-slate-900",
        "text-slate-900 dark:text-slate-50",
      )}
    >
      <main className="flex-1 overflow-hidden relative">
        {activeTab === "home" && (
          <div key="home" className="h-full animate-in fade-in slide-in-from-bottom-5 duration-300">
            <HomePage toggleDarkMode={() => setIsDarkMode(!isDarkMode)} isDarkMode={isDarkMode} />
          </div>
        )}

        {activeTab === "scan" && (
          <div key="scan" className="h-full animate-in fade-in slide-in-from-bottom-5 duration-300">
            <ScanPage />
          </div>
        )}

        {activeTab === "profile" && (
          <div key="profile" className="h-full animate-in fade-in slide-in-from-bottom-5 duration-300">
            <ProfilePage />
          </div>
        )}
      </main>

      {/* Chat Assistant */}
      <ChatAssistant />

      {/* Floating Navigation */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <div className="flex items-center gap-2 p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 dark:bg-black/20 shadow-lg animate-in slide-in-from-bottom-10 duration-500">
          <NavButton
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              </svg>
            }
            isActive={activeTab === "home"}
            onClick={() => setActiveTab("home")}
          />

          <NavButton
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="12" x2="12" y1="8" y2="16" />
                <line x1="8" x2="16" y1="12" y2="12" />
              </svg>
            }
            isActive={activeTab === "scan"}
            onClick={() => setActiveTab("scan")}
            isPrimary
          />

          <NavButton
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            }
            isActive={activeTab === "profile"}
            onClick={() => setActiveTab("profile")}
          />
        </div>
      </div>
    </div>
  )
}

function NavButton({ icon, isActive, onClick, isPrimary = false }) {
  return (
    <button
      className={cn(
        "relative flex items-center justify-center transition-transform active:scale-95",
        isPrimary ? "w-16 h-16" : "w-12 h-12",
        isActive ? "text-white" : "text-slate-400 dark:text-slate-500",
      )}
      onClick={onClick}
    >
      {isActive && (
        <div
          className={cn(
            "absolute inset-0 rounded-full transition-all duration-300",
            isPrimary
              ? "bg-gradient-to-tr from-violet-600 to-indigo-600"
              : "bg-gradient-to-tr from-indigo-600 to-violet-600",
          )}
        />
      )}
      <span className="relative z-10">{icon}</span>
    </button>
  )
}

